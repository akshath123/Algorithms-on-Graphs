#include <iostream>
#include <vector>
#include <queue>

using std::vector;
using std::queue;

int bipartite(vector<vector<int> > &adj) {

  vector<int> colours(adj.size(), -1) ;
  queue<int> buffer;

  buffer.push(0) ;
  colours[0] = 0 ;

  while( !buffer.empty() ){
	int u = buffer.front() ;
  	buffer.pop() ;

 	for(int i = 0 ; i < adj[u].size() ; i++ ){
           int v = adj[u][i] ;
	   if( colours[v] == -1 ){
		colours[v] = 1 - colours[u] ;
		buffer.push(v) ;
	   }
	   else if( colours[v] == colours[u] ){
		return 0 ;
	   }
	}
  }
  
  return 1;
}

int main() {
  int n, m;
  std::cin >> n >> m;
  vector<vector<int> > adj(n, vector<int>());
  for (int i = 0; i < m; i++) {
    int x, y;
    std::cin >> x >> y;
    adj[x - 1].push_back(y - 1);
    adj[y - 1].push_back(x - 1);
  }
  std::cout << bipartite(adj);
}
