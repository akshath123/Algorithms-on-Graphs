#include <iostream>
#include <vector>

using std::vector;
using std::pair;

int dfs(vector<vector<int> > adj, int v, vector<int> &visited, vector<int> &racksize){
 
 	visited[v] = 1 ;
	racksize[v] = 1 ;
	for(int i = 0 ; i < adj[v].size() ; i++ ){
		if( !visited[adj[v][i]] && dfs(adj, adj[v][i], visited, racksize) ){
		  return 1 ;
		}
		if( racksize[adj[v][i]] )
		  return 1 ;
	}
	racksize[v] = 0 ;
	return 0 ;
}

int acyclic(vector<vector<int> > &adj) {

  vector<int> visited(adj.size()) ;
  vector<int> racksize(adj.size()) ;
  for(int i = 0 ; i < adj.size() ; i++ ){
	if( !visited[i] )
		if( dfs(adj, i, visited, racksize) )
			return 1 ;
  }

  return 0;
}

int main() {
  size_t n, m;
  std::cin >> n >> m;
  vector<vector<int> > adj(n, vector<int>());
  for (size_t i = 0; i < m; i++) {
    int x, y;
    std::cin >> x >> y;
    adj[x - 1].push_back(y - 1);
  }
  std::cout << acyclic(adj);
}
